import Mock from 'mockjs'

let data = [
    {
        "result": "ok",
        "page": 1,
        "count": 12,
        "total": 32,
        "goodList": [
            {
                "id": "1001",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_1.jpg",
                "price": 278,
                "isFreePost": true,
                "buyCount": 262,
                "name": "水墨青华2017夏装新款女装气质时尚通勤短袖修身中长款印花连衣裙",
                "shopId": "shop_001",
                "shop": "韩都衣舍旗舰店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "广东 深圳",
                "detailLink": "\/\/detail.tmall.com\/item.htm?spm=a230r.1.14.77.ebb2eb2jQm5ak&id=532891302479&ns=1&abbucket=6"
            },
            {
                "id": "1002",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_2.jpg",
                "price": 386,
                "isFreePost": true,
                "buyCount": 1192,
                "name": "韩版修身显瘦中长款真丝连衣裙2017夏装新款桑蚕丝印花大摆沙滩裙",
                "shopId": "shop_001",
                "shop": "韩都衣舍旗舰店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1003",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_3.jpg",
                "price": 136,
                "isFreePost": true,
                "buyCount": 2710,
                "name": "韩都衣舍2017夏新款韩版网纱小清新假两件中长款连衣裙女RW6789瑒",
                "shopId": "shop_001",
                "shop": "韩都衣舍旗舰店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "山东 济南",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1004",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_4.jpg",
                "price": 158,
                "isFreePost": true,
                "buyCount": 355,
                "name": "2017夏季新款女装韩版复古chic气质小黑裙子百褶中长款吊带连衣裙",
                "shopId": "shop_002",
                "shop": "丽人家beauty",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "广东 东莞",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1005",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_5.jpg",
                "price": 168,
                "isFreePost": true,
                "buyCount": 147,
                "name": "2017夏季新款女装韩版气质修身碎花裙子中长款印花雪纺连衣裙女夏",
                "shopId": "shop_002",
                "shop": "丽人家beauty",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1006",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_6.jpg",
                "price": 148,
                "isFreePost": true,
                "buyCount": 3578,
                "name": "粉色无袖雪纺连衣裙中长款2017夏季新款女装韩版时尚修身裙子长裙",
                "shopId": "shop_002",
                "shop": "丽人家beauty",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1007",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_7.jpg",
                "price": 29,
                "isFreePost": true,
                "buyCount": 4766,
                "name": "无袖娃娃裙大码女装棉麻韩版宽松高腰圆领背心裙亚麻连衣裙女夏季",
                "shopId": "shop_002",
                "shop": "丽人家beauty",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "广东 广州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1008",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_8.jpg",
                "price": 58,
                "isFreePost": true,
                "buyCount": 2132,
                "name": "2017夏装新款裙子棉绸中老年女装印花连衣裙妈妈装加大码短袖长裙",
                "shopId": "shop_003",
                "shop": "茹淘服饰专营店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "北京",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1009",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_9.jpg",
                "price": 89,
                "isFreePost": true,
                "buyCount": 1212,
                "name": "2017夏季新款韩版女装雪纺无袖白色连衣裙夏修身显瘦打底a字裙子",
                "shopId": "shop_003",
                "shop": "茹淘服饰专营店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1010",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_10.jpg",
                "price": 29.9,
                "isFreePost": true,
                "buyCount": 8736,
                "name": "夏季2017新款小清新露肩雪纺连衣裙夏女装韩版显瘦气质a字裙子",
                "shopId": "shop_003",
                "shop": "茹淘服饰专营店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1011",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_11.jpg",
                "price": 138,
                "isFreePost": true,
                "buyCount": 3998,
                "name": "2017新款女装夏季雪纺连衣裙韩版收腰显瘦气质荷叶边系带印花中裙",
                "shopId": "shop_003",
                "shop": "茹淘服饰专营店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "1012",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/goodList\/pics_small\/good_12.jpg",
                "price": 79.9,
                "isFreePost": true,
                "buyCount": 5921,
                "name": "歌兔连衣裙雪纺夏季长裙修身2017新款女装显瘦碎花小清新裙子夏女",
                "shopId": "shop_003",
                "shop": "茹淘服饰专营店",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            }
        ],
        "hotSale_right": [
            {
                "id": "10001",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_1.jpg",
                "price": 158,
                "isFreePost": true,
                "buyCount": 32,
                "name": "女装宽松显瘦a字裙大码雪纺娃娃连衣裙子女",
                "property": [
                    "面料: 雪纺",
                    "裙型: A字裙",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "腰型: 高腰"
                ],
                "address": "广东 深圳",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10002",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_2.jpg",
                "price": 158,
                "isFreePost": true,
                "buyCount": 195,
                "name": "女装夏季 雪纺短袖欧根纱裙套装",
                "property": [
                    "组合形式: 两件套",
                    "袖长: 短袖",
                    "领型: 圆领",
                    "通勤: 韩版",
                    "面料: 雪纺"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10003",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_3.jpg",
                "price": 158,
                "isFreePost": true,
                "buyCount": 616,
                "name": "2017夏季新款女装韩版气质碎花雪纺女连衣裙",
                "property": [
                    "面料: 雪纺",
                    "通勤: 韩版",
                    "服装款式细节: 印花",
                    "袖长: 短袖",
                    "领型: V领"
                ],
                "address": "山东 济南",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10004",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_4.jpg",
                "price": 138,
                "isFreePost": true,
                "buyCount": 6701,
                "name": "欧洲站新款无袖圆领印花修身中长款连衣裙潮",
                "property": [
                    "服装款式细节: 印花",
                    "领型: 圆领",
                    "风格: 通勤",
                    "裙长: 中裙",
                    "尺码: M"
                ],
                "address": "广东 东莞",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10005",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_5.jpg",
                "price": 339,
                "isFreePost": true,
                "buyCount": 47,
                "name": "时尚名媛镂空黑色高腰中长款小黑裙连衣裙",
                "property": [],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10006",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_6.jpg",
                "price": 109,
                "isFreePost": true,
                "buyCount": 33,
                "name": "ur女装夏季v领a字裙中长款连衣裙雪纺连衣裙",
                "property": [
                    "领型: V领",
                    "面料: 雪纺",
                    "服装款式细节: 蝴蝶结",
                    "袖长: 短袖",
                    "尺码: L"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10007",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_7.jpg",
                "price": 138,
                "isFreePost": true,
                "buyCount": 5471,
                "name": "韩版v领中长款a裙仙女装夏季棉麻连衣裙",
                "property": [
                    "通勤: 韩版",
                    "领型: V领",
                    "袖长: 短袖",
                    "材质: 麻",
                    "裙长: 中长款"
                ],
                "address": "广东 广州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10008",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_8.jpg",
                "price": 225,
                "isFreePost": true,
                "buyCount": 263,
                "name": "中学生宽松棉麻连衣裙娃娃裙2017夏季说时尚",
                "property": [
                    "材质: 麻",
                    "袖长: 短袖",
                    "通勤: 文艺",
                    "图案: 碎花",
                    "领型: 圆领"
                ],
                "address": "北京",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10009",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_9.jpg",
                "price": 158,
                "isFreePost": true,
                "buyCount": 18,
                "name": "名媛女装夏季 雪纺收腰圆领无袖裙",
                "property": [
                    "面料: 雪纺",
                    "裙长: 中裙",
                    "通勤: 韩版",
                    "领型: 圆领",
                    "风格: 通勤"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10010",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_10.jpg",
                "price": 158.9,
                "isFreePost": true,
                "buyCount": 1200,
                "name": "小清新雪纺连衣裙女夏季2017新款显瘦印花裙",
                "property": [
                    "面料: 雪纺",
                    "领型: V领",
                    "裙长: 中裙",
                    "服装款式细节: 印花",
                    "通勤: 韩版"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10011",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_11.jpg",
                "price": 99,
                "isFreePost": true,
                "buyCount": 154,
                "name": "2017女夏季韩版精美印花吊带裙套装连衣套裙",
                "property": [
                    "通勤: 韩版",
                    "款式: 吊带",
                    "组合形式: 两件套",
                    "服装款式细节: 印花",
                    "腰型: 高腰"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "10012",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_right\/hotSale_12.jpg",
                "price": 79,
                "isFreePost": true,
                "buyCount": 190,
                "name": "包邮 夜店性感气质交叉V领喇叭袖格子连衣裙",
                "property": [
                    "领型: V领",
                    "图案: 格子",
                    "通勤: 韩版",
                    "服装款式细节: 荷叶边",
                    "袖型: 喇叭袖"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            }
        ],
        "hotSale_bottom": [
            {
                "id": "100001",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_bottom\/hotSale_1.jpg",
                "price": 138,
                "oldPrice": 198,
                "isFreePost": true,
                "buyCount": 12359,
                "name": "2017夏季短袖v领显瘦时尚小清新蕾丝连衣裙",
                "manager": "星号2",
                "property": [
                    "通勤: 韩版",
                    "领型: V领",
                    "面料: 蕾丝",
                    "裙长: 中裙",
                    "袖长: 短袖"
                ],
                "address": "广东 深圳",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "100002",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_bottom\/hotSale_2.jpg",
                "price": 168,
                "oldPrice": 588,
                "isFreePost": true,
                "buyCount": 4643,
                "name": "连衣裙女夏2017夏季OL中长款复古欧根纱裙子",
                "manager": "桐杭之恋",
                "property": [
                    "面料: 雪纺",
                    "通勤: 韩版",
                    "袖长: 短袖",
                    "腰型: 高腰",
                    "服装款式细节: 绣花"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "100003",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_bottom\/hotSale_3.jpg",
                "price": 65,
                "oldPrice": 315,
                "isFreePost": true,
                "buyCount": 417,
                "name": "2017夏装大码女装宽松遮肚子假两件连衣裙潮",
                "manager": "广州安防比色兔",
                "property": [
                    "款式品名: 连衣裙",
                    "组合形式: 假两件",
                    "服装版型: 宽松",
                    "袖长: 短袖",
                    "通勤: 韩版"
                ],
                "address": "山东 济南",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "100004",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_bottom\/hotSale_4.jpg",
                "price": 137,
                "oldPrice": 298,
                "isFreePost": true,
                "buyCount": 25,
                "name": "夏季女装原创棉麻白色亚麻料连衣裙中长款",
                "manager": "雨笛晓晓",
                "property": [
                    "颜色分类: 白色",
                    "材质: 麻",
                    "裙长: 中长款",
                    "图案: 纯色",
                    "风格: 通勤"
                ],
                "address": "广东 东莞",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            },
            {
                "id": "100005",
                "pic": "http:\/\/www.yantianfeng.com\/static\/images\/api\/hotSale_bottom\/hotSale_5.jpg",
                "price": 168,
                "oldPrice": 468,
                "isFreePost": true,
                "buyCount": 65,
                "name": "连衣裙气质优雅水墨飘逸宽松中长款时尚裙子",
                "manager": "酷布朗男装",
                "property": [
                    "裙长: 中长款",
                    "袖长: 短袖",
                    "服装款式细节: 褶皱",
                    "风格: 通勤",
                    "领型: 圆领"
                ],
                "address": "浙江 杭州",
                "detailLink": "\/\/item.taobao.com\/item.htm?spm=a230r.1.14.22.ebb2eb2jQm5ak&id=553249213275&ns=1&abbucket=6#detail"
            }
        ]
    }
]

Mock.mock('/getData',()=>{
    return data
})

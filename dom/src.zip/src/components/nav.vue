<template>
  <div class="nav">
    <p @click='sort' v-for="(item,index) in list" :key="index">
        {{item.name}}
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [
        { name: "价格升序↑", path: "/jiagesheng" },
        { name: "价格降序↓", path: "/jiagejiang" },
        { name: "销量升序↑", path: "/xiaoliangsheng" },
        { name: "销量降序↓", path: "/xiaoliangjiang" }
      ]
    };
  },
  methods: {
    sort(){
      alert(1)
    }
  }
};
</script>

<style lang="scss" scoped>
.nav{
    display: flex;
    justify-content: space-around;
    border-bottom: 1px solid #ccc;
}
</style>
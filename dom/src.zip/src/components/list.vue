<template>
    <div>
        <div class="ul" v-for='(item,index) in userList' :key="index">
          <div class="left">
              <img :src=item.pic alt="">
          </div>
           <div class="right">
               <p>{{item.name}}</p>
               <p>已售:{{item.buyCount}}件</p>
               <div>单价:<span class="span">￥{{item.price}}</span> </div>
               <button class="btn" @click='btn'>加入购物车</button>          
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios'
import '../mock/mock.js'

export default {
    mounted () {
        axios.get('/getData').then(res=>{
            res.data.map((item,index)=>{
                this.userList = item.goodList
            })
        })
    },
    data(){
        return{
            userList:[]
        }
    },
    methods: {
        btn(){ 
        }
    },

}
</script>

<style lang="scss" scoped>
*{
    margin: 0;
    padding: 0;
    list-style: none;
}
.ul{
    width: 100%;
    height: 100px;
    display: flex;
    align-items: center;
    position: relative;
    .left{
        width: 30%;
        img{
            width: 100%;
        }
    }
    .right{
        padding-left: 10px;
    }
    .btn{
        position: absolute;
        bottom: 10px;
        right: 5px;
        background: #f00;
        outline: none;
        border: 0;
        padding: 5px 10px;
        color: #fff;
    }
    .span{
        color: #f00;
    }
}
</style>